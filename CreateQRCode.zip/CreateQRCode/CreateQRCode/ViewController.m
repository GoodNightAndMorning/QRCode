//
//  ViewController.m
//  CreateQRCode
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "ViewController.h"
#import "SXQRMethods.h"
@interface ViewController ()
@property(nonatomic,strong)UIImageView *imageView;

@property(nonatomic,strong)SXQRMethods *qr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.imageView.image = [SXQRMethods createQRWithStr:@"https://www.baidu.com"];
    
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    _qr = [[SXQRMethods alloc] init];
    [_qr scanQRWithLayer:self.view.layer completeHandle:^(NSString *str) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"在浏览器中打开链接" message:str preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        UIAlertAction *confirm = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
        }];
        [alert addAction:cancel];
        [alert addAction:confirm];
        [self presentViewController:alert animated:YES completion:nil];
    }];

    CATextLayer *layer = [CATextLayer layer];
    layer.frame = CGRectMake(0, 50, 320, 20);
    layer.string = @"hello world";
    layer.fontSize = 14;
    layer.contentsScale = 2;
    layer.font = (__bridge CFTypeRef)(@"HiraKakuProN-W3");
    layer.alignmentMode = @"center";
    [self.view.layer addSublayer:layer];
}


-(void)discernQRCode{
    NSString *scannedResult = [SXQRMethods discernQRCodeFromImage:self.imageView.image];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"在浏览器中打开链接" message:scannedResult preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *confirm = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:scannedResult]];
    }];
    [alert addAction:cancel];
    [alert addAction:confirm];
    [self presentViewController:alert animated:YES completion:nil];
}
-(UIImageView *)imageView{
    if (!_imageView) {
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 80, 80)];
        _imageView.center = self.view.center;
        _imageView.userInteractionEnabled = YES;
        UITapGestureRecognizer *longPress = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(discernQRCode)];
        [_imageView addGestureRecognizer:longPress];
        [self.view addSubview:_imageView];
    }
    return _imageView;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
