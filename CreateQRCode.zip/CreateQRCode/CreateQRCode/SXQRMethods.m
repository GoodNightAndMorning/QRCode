//
//  SXQRMethods.m
//  CreateQRCode
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "SXQRMethods.h"
#import <CoreImage/CoreImage.h>
#import <AVFoundation/AVFoundation.h>
@interface SXQRMethods ()<AVCaptureMetadataOutputObjectsDelegate>

@property(nonatomic,strong)AVCaptureSession *captureSession;
@property(nonatomic,strong)AVCaptureVideoPreviewLayer *videoPreviewLayer;

@property(nonatomic,copy)void(^completeHandle)(NSString *str);
@end
@implementation SXQRMethods

/**
 生成二维码
 
 @param str 信息字符串
 @return 二维码图片
 */
+(UIImage *)createQRWithStr:(NSString *)str{
    // 1. 创建一个二维码滤镜实例(CIFilter)
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 滤镜恢复默认设置
    [filter setDefaults];
    
    // 2. 给滤镜添加数据
    NSString *string = str;
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    // 使用KVC的方式给filter赋值
    [filter setValue:data forKeyPath:@"inputMessage"];
    
    // 3. 生成二维码
    CIImage *image = [filter outputImage];
    
    // 4. 显示二维码
    return [self p_createNonInterpolatedUIImageFormCIImage:image withSize:320];
}
+ (UIImage *)p_createNonInterpolatedUIImageFormCIImage:(CIImage *)image withSize:(CGFloat) size {
    
    CGRect extent = CGRectIntegral(image.extent);
    CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
    
    // 1.创建bitmap;
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [context createCGImage:image fromRect:extent];
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    
    // 2.保存bitmap到图片
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);
    CGImageRelease(bitmapImage);
    return [UIImage imageWithCGImage:scaledImage];
}
/**
 识别图中二维码
 
 @param image 识别的图片
 @return 二维码信息字符串
 */
+(NSString *)discernQRCodeFromImage:(UIImage *)image{
    //1. 初始化扫描仪，设置设别类型和识别质量
    CIDetector*detector = [CIDetector detectorOfType:CIDetectorTypeQRCode context:nil options:@{ CIDetectorAccuracy : CIDetectorAccuracyHigh }];
    //2. 扫描获取的特征组
    NSArray *features = [detector featuresInImage:[CIImage imageWithCGImage:image.CGImage]];
    //3. 获取扫描结果
    NSLog(@"%@",features);
    CIQRCodeFeature *feature = [features objectAtIndex:0];
    
    NSString *scannedResult = feature.messageString;
    return scannedResult;
}

/**
 二维码扫描
 
 @param layer 展示layer
 @param completeHandle 扫描结果回调
 */
-(void)scanQRWithLayer:(CALayer *)layer completeHandle:(void(^)(NSString *str))completeHandle{
    
    self.completeHandle = completeHandle;
    
    //初始化捕捉设备AVCaptureDevice
    AVCaptureDevice *captureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    //创建输入
    NSError *error = nil;
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:captureDevice error:&error];
    if (!input) {
        NSLog(@"%@", [error localizedDescription]);
        return;
    }
    //创建输出
    AVCaptureMetadataOutput *captureMetadataOutput = [[AVCaptureMetadataOutput alloc] init];
    
    //创建一个会话，并添加输入和输出
    self.captureSession = [[AVCaptureSession alloc] init];
    [self.captureSession addInput:input];
    [self.captureSession addOutput:captureMetadataOutput];
    
    //设置输出数据的类型，AVMetadataObjectTypeQRCode为二维码类型，其他类型可以到这个头文件AVMetadataObject.h里面查看
    [captureMetadataOutput setMetadataObjectTypes:[NSArray arrayWithObject:AVMetadataObjectTypeQRCode]];
    
    //创建图层，摄像头捕捉到的画面都会在这个图层显示
    self.videoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:self.captureSession];
    [self.videoPreviewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
    [self.videoPreviewLayer setFrame:[UIScreen mainScreen].bounds];
    
    if (layer) {
        [layer addSublayer:self.videoPreviewLayer];
    }else{
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        
        [window.layer addSublayer:self.videoPreviewLayer];
    }
    
    //创建一个串行队列，并设置代理
    dispatch_queue_t dispatchQueue;
    dispatchQueue = dispatch_queue_create("myQueue", NULL);
    [captureMetadataOutput setMetadataObjectsDelegate:self queue:dispatchQueue];
    
    //设置扫码范围
    captureMetadataOutput.rectOfInterest = CGRectMake(0.2f, 0.2f, 0.8f, 0.8f);
    
    //开始扫码
    [self.captureSession startRunning];
}
-(void)captureOutput:(AVCaptureOutput *)output didOutputMetadataObjects:(NSArray<__kindof AVMetadataObject *> *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
    //判断是否有数据
    if (metadataObjects != nil && [metadataObjects count] > 0) {
        AVMetadataMachineReadableCodeObject *metadataObj = [metadataObjects objectAtIndex:0];
        //判断回传的数据类型
        if ([[metadataObj type] isEqualToString:AVMetadataObjectTypeQRCode]) {
            NSString * license = [metadataObj stringValue];
            if (self.completeHandle) {
                self.completeHandle(license);
            }
            [self performSelectorOnMainThread:@selector(p_stopReading) withObject:nil waitUntilDone:NO];
        }
    }
}
-(void)p_stopReading{
    [self.captureSession stopRunning];
    [self.videoPreviewLayer removeFromSuperlayer];
    self.videoPreviewLayer = nil;
    self.captureSession = nil;
}
@end
