//
//  SXQRMethods.h
//  CreateQRCode
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface SXQRMethods : NSObject

/**
 生成二维码

 @param str 信息字符串
 @return 二维码图片
 */
+(UIImage *)createQRWithStr:(NSString *)str;

/**
 识别图中二维码

 @param image 识别的图片
 @return 二维码信息字符串
 */
+(NSString *)discernQRCodeFromImage:(UIImage *)image;

/**
 二维码扫描

 @param layer 展示layer
 @param completeHandle 扫描结果回调
 */
-(void)scanQRWithLayer:(CALayer *)layer completeHandle:(void(^)(NSString *str))completeHandle;
@end
